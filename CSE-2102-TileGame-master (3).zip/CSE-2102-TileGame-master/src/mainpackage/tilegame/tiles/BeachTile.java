package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class BeachTile extends Tile {

	public BeachTile(int id) {
		super(Assets.beach, id);
	}

}
