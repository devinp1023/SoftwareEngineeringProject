package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class DirtTile extends Tile {

	public DirtTile(int id) {
		super(Assets.dirt, id);
		
	}
}
