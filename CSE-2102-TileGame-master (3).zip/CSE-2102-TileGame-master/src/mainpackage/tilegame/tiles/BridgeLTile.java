package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class BridgeLTile extends Tile{

	public BridgeLTile( int id) {
		super(Assets.bridgeL, id);
	}

}
