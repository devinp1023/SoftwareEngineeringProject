package mainpackage.tilegame.tiles;


import mainpackage.tilegame.graphics.Assets;

public class MudTile extends Tile {

	public MudTile(int id) {
		super(Assets.mud, id);
	}

}
