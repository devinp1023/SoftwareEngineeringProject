package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class WhiteTileTile extends Tile {

	public WhiteTileTile(int id) {
		super(Assets.whiteTile, id);
		
	}
}
