package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class BridgeRTile extends Tile{

	public BridgeRTile(int id) {
		super(Assets.bridgeR, id);
	}

}
