package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class SandTile extends Tile{

	public SandTile(int id) {
		super(Assets.sand, id);
		
	}
	

}
