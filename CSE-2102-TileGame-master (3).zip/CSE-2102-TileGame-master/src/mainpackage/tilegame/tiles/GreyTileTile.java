package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class GreyTileTile extends Tile {
	
	public GreyTileTile(int id) {
		super(Assets.greyTile, id);
		
	}
}
