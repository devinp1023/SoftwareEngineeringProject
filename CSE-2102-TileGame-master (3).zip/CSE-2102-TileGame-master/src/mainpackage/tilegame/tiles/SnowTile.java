package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class SnowTile extends Tile{

	public SnowTile(int id) {
		super(Assets.snow, id);
		
	}

}
