package mainpackage.tilegame.tiles;

import mainpackage.tilegame.graphics.Assets;

public class WoodTile extends Tile {

	public WoodTile(int id) {
		super(Assets.wood, id);
		
	}
}
